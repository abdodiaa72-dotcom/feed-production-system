"use client";

import { useState } from "react";
import DailySection from "./sections/DailySection";
import SalesSection from "./sections/SalesSection";
import PurchasesSection from "./sections/PurchasesSection";
import CustomersSection from "./sections/CustomersSection";
import SuppliersSection from "./sections/SuppliersSection";
import MaterialsSection from "./sections/MaterialsSection";
import FeedTypesSection from "./sections/FeedTypesSection";
import ManufacturingSection from "./sections/ManufacturingSection";
import WorkersSection from "./sections/WorkersSection";
import ExpensesSection from "./sections/ExpensesSection";
import TreasurySection from "./sections/TreasurySection";
import ReceiptsSection from "./sections/ReceiptsSection";

interface DashboardProps {
  user: { id: number; username: string; role: string };
  onLogout: () => void;
}

const menuItems = [
  { key: "daily", label: "اليومية", icon: "📋" },
  { key: "sales", label: "المبيعات", icon: "💰" },
  { key: "purchases", label: "المشتريات", icon: "🛒" },
  { key: "customers", label: "العملاء", icon: "👥" },
  { key: "suppliers", label: "الموردين", icon: "🏪" },
  { key: "materials", label: "الخامات", icon: "📦" },
  { key: "feedTypes", label: "أصناف العلف", icon: "🌾" },
  { key: "manufacturing", label: "التصنيع", icon: "🏭" },
  { key: "workers", label: "العمال", icon: "👷" },
  { key: "expenses", label: "المصروفات", icon: "📝" },
  { key: "treasury", label: "الخزنة", icon: "🏦" },
  { key: "receipts", label: "السندات", icon: "🧾" },
];

export default function Dashboard({ user, onLogout }: DashboardProps) {
  const [activeSection, setActiveSection] = useState("daily");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    onLogout();
  };

  const renderSection = () => {
    switch (activeSection) {
      case "daily": return <DailySection />;
      case "sales": return <SalesSection />;
      case "purchases": return <PurchasesSection />;
      case "customers": return <CustomersSection />;
      case "suppliers": return <SuppliersSection />;
      case "materials": return <MaterialsSection />;
      case "feedTypes": return <FeedTypesSection />;
      case "manufacturing": return <ManufacturingSection />;
      case "workers": return <WorkersSection />;
      case "expenses": return <ExpensesSection />;
      case "treasury": return <TreasurySection />;
      case "receipts": return <ReceiptsSection />;
      default: return <DailySection />;
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 right-0 z-30 h-screen w-64 bg-sidebar text-white flex flex-col transition-transform duration-300 ${
          sidebarOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"
        }`}
      >
        <div className="p-5 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary-light to-accent rounded-xl flex items-center justify-center text-lg">
              🏭
            </div>
            <div>
              <h2 className="font-bold text-sm">مصنع الأعلاف</h2>
              <p className="text-xs text-slate-400">نظام الإدارة</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-4">
          {menuItems.map((item) => (
            <button
              key={item.key}
              onClick={() => {
                setActiveSection(item.key);
                setSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-5 py-3 text-sm font-medium transition-all ${
                activeSection === item.key
                  ? "bg-sidebar-active text-white border-l-4 border-primary-light"
                  : "text-slate-300 hover:bg-sidebar-hover hover:text-white"
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-700">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-sm">
              👤
            </div>
            <div>
              <p className="text-sm font-medium">{user.username}</p>
              <p className="text-xs text-slate-400">
                {user.role === "admin" ? "مدير" : "محاسب"}
              </p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="w-full bg-danger/20 text-red-300 hover:bg-danger/30 py-2 rounded-lg text-sm font-medium transition-colors"
          >
            تسجيل الخروج
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-h-screen">
        {/* Top Bar */}
        <header className="bg-white shadow-sm border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden text-2xl text-slate-600"
            >
              ☰
            </button>
            <h1 className="text-xl font-bold text-slate-800">
              {menuItems.find((i) => i.key === activeSection)?.icon}{" "}
              {menuItems.find((i) => i.key === activeSection)?.label}
            </h1>
          </div>
          <div className="text-sm text-slate-500">
            {new Date().toLocaleDateString("ar-EG", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </div>
        </header>

        {/* Content */}
        <div className="p-6 fade-in">{renderSection()}</div>
      </main>
    </div>
  );
}
