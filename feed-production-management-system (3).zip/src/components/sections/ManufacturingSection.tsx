"use client";

import { useState, useEffect, useCallback } from "react";

interface Mfg { id: number; feedTypeName: string | null; quantityTons: string; date: string; notes: string | null; }
interface FeedType { id: number; name: string; }
interface Material { id: number; name: string; unit: string | null; quantity: string | null; }

export default function ManufacturingSection() {
  const [records, setRecords] = useState<Mfg[]>([]);
  const [feedTypes, setFeedTypes] = useState<FeedType[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    feedTypeId: "", quantityTons: "",
    date: new Date().toISOString().split("T")[0], notes: "",
  });
  const [matUsed, setMatUsed] = useState<Array<{ materialId: string; quantityUsed: string }>>([]);

  const load = useCallback(async () => {
    const [r, f, m] = await Promise.all([
      fetch("/api/manufacturing").then(r => r.json()),
      fetch("/api/feed-types").then(r => r.json()),
      fetch("/api/materials").then(r => r.json()),
    ]);
    setRecords(r); setFeedTypes(f); setMaterials(m);
  }, []);

  useEffect(() => { load(); }, [load]);

  const addMaterial = () => {
    setMatUsed([...matUsed, { materialId: "", quantityUsed: "" }]);
  };

  const removeMaterial = (index: number) => {
    setMatUsed(matUsed.filter((_, i) => i !== index));
  };

  const updateMaterial = (index: number, field: string, value: string) => {
    const updated = [...matUsed];
    updated[index] = { ...updated[index], [field]: value };
    setMatUsed(updated);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/manufacturing", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        feedTypeId: parseInt(form.feedTypeId),
        materialsUsed: matUsed.filter(m => m.materialId && m.quantityUsed).map(m => ({
          materialId: parseInt(m.materialId),
          quantityUsed: m.quantityUsed,
        })),
      }),
    });
    setForm({ feedTypeId: "", quantityTons: "", date: new Date().toISOString().split("T")[0], notes: "" });
    setMatUsed([]);
    setShowForm(false);
    load();
  };

  const totalTons = records.reduce((sum, r) => sum + parseFloat(r.quantityTons), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-700">سجل التصنيع</h2>
          <p className="text-sm text-slate-500 mt-1">إجمالي ما تم تصنيعه: <span className="font-bold text-blue-600">{totalTons.toLocaleString()} طن</span></p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors">
          {showForm ? "إلغاء" : "➕ تصنيع جديد"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
          <h3 className="font-bold text-lg mb-4 text-slate-700">عملية تصنيع جديدة</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">نوع العلف</label>
              <select value={form.feedTypeId} onChange={e => setForm({ ...form, feedTypeId: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="">اختر نوع العلف</option>
                {feedTypes.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">الكمية (طن)</label>
              <input type="number" step="0.01" value={form.quantityTons} onChange={e => setForm({ ...form, quantityTons: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">التاريخ</label>
              <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">ملاحظات</label>
              <input type="text" value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
          </div>

          {/* Materials Used */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-bold text-slate-700">الخامات المستخدمة (ينقص من المخزون تلقائياً)</h4>
              <button type="button" onClick={addMaterial} className="px-4 py-1.5 bg-blue-50 text-blue-700 rounded-lg text-sm font-bold hover:bg-blue-100">
                ➕ إضافة خامة
              </button>
            </div>
            {matUsed.map((mu, i) => (
              <div key={i} className="flex gap-3 mb-2 fade-in">
                <select value={mu.materialId} onChange={e => updateMaterial(i, "materialId", e.target.value)} className="flex-1 px-3 py-2 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none text-sm">
                  <option value="">اختر الخامة</option>
                  {materials.map(m => <option key={m.id} value={m.id}>{m.name} (متاح: {parseFloat(m.quantity || "0").toLocaleString()} {m.unit})</option>)}
                </select>
                <input type="number" step="0.01" value={mu.quantityUsed} onChange={e => updateMaterial(i, "quantityUsed", e.target.value)} placeholder="الكمية المستخدمة" className="w-40 px-3 py-2 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none text-sm" />
                <button type="button" onClick={() => removeMaterial(i)} className="px-3 py-2 bg-red-50 text-red-600 rounded-xl text-sm hover:bg-red-100">🗑️</button>
              </div>
            ))}
          </div>

          <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">حفظ عملية التصنيع</button>
        </form>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-4 py-3 text-right font-bold text-slate-600">#</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">التاريخ</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">نوع العلف</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">الكمية (طن)</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">ملاحظات</th>
              </tr>
            </thead>
            <tbody>
              {records.map((r, i) => (
                <tr key={r.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 text-slate-500">{i + 1}</td>
                  <td className="px-4 py-3">{r.date}</td>
                  <td className="px-4 py-3 font-medium">{r.feedTypeName}</td>
                  <td className="px-4 py-3 font-bold text-blue-700">{r.quantityTons} طن</td>
                  <td className="px-4 py-3 text-slate-500">{r.notes || "-"}</td>
                </tr>
              ))}
              {records.length === 0 && (
                <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400">لا يوجد عمليات تصنيع بعد</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
