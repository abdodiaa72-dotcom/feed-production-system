"use client";

import { useState, useEffect, useCallback } from "react";

interface Supplier { id: number; name: string; phone: string | null; address: string | null; balance: string | null; }

export default function SuppliersSection() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", address: "" });

  const load = useCallback(async () => {
    const data = await fetch("/api/suppliers").then(r => r.json());
    setSuppliers(data);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/suppliers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setForm({ name: "", phone: "", address: "" });
    setShowForm(false);
    load();
  };

  const totalBalance = suppliers.reduce((sum, s) => sum + parseFloat(s.balance || "0"), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-700">إدارة الموردين</h2>
          <p className="text-sm text-slate-500 mt-1">إجمالي المستحقات للموردين: <span className="font-bold text-red-600">{totalBalance.toLocaleString()} ج.م</span></p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors">
          {showForm ? "إلغاء" : "➕ مورد جديد"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
          <h3 className="font-bold text-lg mb-4 text-slate-700">إضافة مورد جديد</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">اسم المورد</label>
              <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">رقم الهاتف</label>
              <input type="text" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">العنوان</label>
              <input type="text" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
          </div>
          <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">حفظ</button>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {suppliers.map(s => (
          <div key={s.id} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 hover:shadow-md transition-shadow">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center text-xl">🏪</div>
              <div>
                <h3 className="font-bold text-slate-800">{s.name}</h3>
                {s.phone && <p className="text-sm text-slate-500">{s.phone}</p>}
              </div>
            </div>
            {s.address && <p className="text-sm text-slate-500 mb-3">📍 {s.address}</p>}
            <div className={`p-3 rounded-xl ${parseFloat(s.balance || "0") > 0 ? "bg-red-50" : "bg-green-50"}`}>
              <p className="text-xs text-slate-500">المستحقات</p>
              <p className={`text-xl font-black ${parseFloat(s.balance || "0") > 0 ? "text-red-600" : "text-green-600"}`}>
                {parseFloat(s.balance || "0").toLocaleString()} ج.م
              </p>
            </div>
          </div>
        ))}
        {suppliers.length === 0 && (
          <div className="col-span-full bg-white rounded-2xl shadow-sm border border-slate-200 p-12 text-center">
            <span className="text-4xl mb-3 block">🏪</span>
            <p className="text-slate-400">لا يوجد موردين بعد</p>
          </div>
        )}
      </div>
    </div>
  );
}
