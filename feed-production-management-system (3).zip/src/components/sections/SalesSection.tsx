"use client";

import { useState, useEffect, useCallback } from "react";

interface Sale {
  id: number; customerName: string | null; feedTypeName: string | null;
  quantity: string; pricePerTon: string; totalPrice: string;
  paymentType: string; date: string; notes: string | null;
}
interface Customer { id: number; name: string; }
interface FeedType { id: number; name: string; pricePerTon: string | null; }

export default function SalesSection() {
  const [sales, setSales] = useState<Sale[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [feedTypes, setFeedTypes] = useState<FeedType[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    customerId: "", feedTypeId: "", quantity: "", pricePerTon: "",
    paymentType: "cash", date: new Date().toISOString().split("T")[0], notes: "",
  });

  const load = useCallback(async () => {
    const [s, c, f] = await Promise.all([
      fetch("/api/sales").then(r => r.json()),
      fetch("/api/customers").then(r => r.json()),
      fetch("/api/feed-types").then(r => r.json()),
    ]);
    setSales(s); setCustomers(c); setFeedTypes(f);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/sales", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        customerId: parseInt(form.customerId),
        feedTypeId: parseInt(form.feedTypeId),
      }),
    });
    setForm({ customerId: "", feedTypeId: "", quantity: "", pricePerTon: "", paymentType: "cash", date: new Date().toISOString().split("T")[0], notes: "" });
    setShowForm(false);
    load();
  };

  const handleFeedTypeChange = (feedTypeId: string) => {
    setForm(f => ({ ...f, feedTypeId }));
    const ft = feedTypes.find(t => t.id === parseInt(feedTypeId));
    if (ft && ft.pricePerTon) {
      setForm(f => ({ ...f, feedTypeId, pricePerTon: ft.pricePerTon || "" }));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-700">سجل المبيعات</h2>
        <button onClick={() => setShowForm(!showForm)} className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors">
          {showForm ? "إلغاء" : "➕ بيع جديد"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
          <h3 className="font-bold text-lg mb-4 text-slate-700">عملية بيع جديدة</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">العميل</label>
              <select value={form.customerId} onChange={e => setForm({ ...form, customerId: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="">اختر العميل</option>
                {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">نوع العلف</label>
              <select value={form.feedTypeId} onChange={e => handleFeedTypeChange(e.target.value)} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="">اختر نوع العلف</option>
                {feedTypes.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">الكمية (طن)</label>
              <input type="number" step="0.01" value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">سعر الطن</label>
              <input type="number" step="0.01" value={form.pricePerTon} onChange={e => setForm({ ...form, pricePerTon: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">نوع الدفع</label>
              <select value={form.paymentType} onChange={e => setForm({ ...form, paymentType: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="cash">نقدي</option>
                <option value="credit">آجل</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">التاريخ</label>
              <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div className="md:col-span-2 lg:col-span-3">
              <label className="block text-sm font-semibold text-slate-600 mb-1">ملاحظات</label>
              <input type="text" value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
          </div>
          {form.quantity && form.pricePerTon && (
            <div className="mt-4 p-3 bg-green-50 rounded-xl text-green-700 font-bold text-lg">
              الإجمالي: {(parseFloat(form.quantity) * parseFloat(form.pricePerTon)).toLocaleString()} ج.م
            </div>
          )}
          <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">
            حفظ عملية البيع
          </button>
        </form>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-4 py-3 text-right font-bold text-slate-600">#</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">التاريخ</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">العميل</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">نوع العلف</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">الكمية</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">سعر الطن</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">الإجمالي</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">الدفع</th>
              </tr>
            </thead>
            <tbody>
              {sales.map((s, i) => (
                <tr key={s.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 text-slate-500">{i + 1}</td>
                  <td className="px-4 py-3">{s.date}</td>
                  <td className="px-4 py-3 font-medium">{s.customerName}</td>
                  <td className="px-4 py-3">{s.feedTypeName}</td>
                  <td className="px-4 py-3">{s.quantity} طن</td>
                  <td className="px-4 py-3">{parseFloat(s.pricePerTon).toLocaleString()}</td>
                  <td className="px-4 py-3 font-bold text-green-700">{parseFloat(s.totalPrice).toLocaleString()} ج.م</td>
                  <td className="px-4 py-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${s.paymentType === "cash" ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"}`}>
                      {s.paymentType === "cash" ? "نقدي" : "آجل"}
                    </span>
                  </td>
                </tr>
              ))}
              {sales.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-8 text-center text-slate-400">لا توجد مبيعات بعد</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
