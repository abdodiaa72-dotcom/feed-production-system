"use client";

import { useState, useEffect, useCallback } from "react";

interface Receipt { id: number; customerId: number | null; customerName: string | null; type: string; amount: string; date: string; notes: string | null; }
interface Customer { id: number; name: string; }

export default function ReceiptsSection() {
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    customerId: "", type: "receipt", amount: "",
    date: new Date().toISOString().split("T")[0], notes: "",
  });

  const load = useCallback(async () => {
    const [r, c] = await Promise.all([
      fetch("/api/receipts").then(r => r.json()),
      fetch("/api/customers").then(r => r.json()),
    ]);
    setReceipts(r); setCustomers(c);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/receipts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        customerId: parseInt(form.customerId),
      }),
    });
    setForm({ customerId: "", type: "receipt", amount: "", date: new Date().toISOString().split("T")[0], notes: "" });
    setShowForm(false);
    load();
  };

  const totalReceipts = receipts.filter(r => r.type === "receipt").reduce((sum, r) => sum + parseFloat(r.amount), 0);
  const totalPayments = receipts.filter(r => r.type === "payment").reduce((sum, r) => sum + parseFloat(r.amount), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-700">سندات القبض والصرف</h2>
          <div className="flex gap-4 mt-1">
            <p className="text-sm text-slate-500">سندات قبض: <span className="font-bold text-green-600">{totalReceipts.toLocaleString()} ج.م</span></p>
            <p className="text-sm text-slate-500">سندات صرف: <span className="font-bold text-red-600">{totalPayments.toLocaleString()} ج.م</span></p>
          </div>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors">
          {showForm ? "إلغاء" : "➕ سند جديد"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
          <h3 className="font-bold text-lg mb-4 text-slate-700">إضافة سند</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">النوع</label>
              <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="receipt">سند قبض (العميل يدفع)</option>
                <option value="payment">سند صرف (ندفع للعميل)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">العميل</label>
              <select value={form.customerId} onChange={e => setForm({ ...form, customerId: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="">اختر العميل</option>
                {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">المبلغ</label>
              <input type="number" step="0.01" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">التاريخ</label>
              <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">ملاحظات</label>
              <input type="text" value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
          </div>
          <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">حفظ السند</button>
        </form>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-4 py-3 text-right font-bold text-slate-600">#</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">التاريخ</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">النوع</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">العميل</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">المبلغ</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">ملاحظات</th>
              </tr>
            </thead>
            <tbody>
              {receipts.map((r, i) => (
                <tr key={r.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 text-slate-500">{i + 1}</td>
                  <td className="px-4 py-3">{r.date}</td>
                  <td className="px-4 py-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${r.type === "receipt" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                      {r.type === "receipt" ? "سند قبض" : "سند صرف"}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-medium">{r.customerName}</td>
                  <td className={`px-4 py-3 font-bold ${r.type === "receipt" ? "text-green-700" : "text-red-700"}`}>
                    {r.type === "receipt" ? "+" : "-"}{parseFloat(r.amount).toLocaleString()} ج.م
                  </td>
                  <td className="px-4 py-3 text-slate-500">{r.notes || "-"}</td>
                </tr>
              ))}
              {receipts.length === 0 && (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400">لا يوجد سندات بعد</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
