"use client";

import { useState, useEffect } from "react";

interface DailyData {
  date: string;
  sales: Array<{ id: number; customerName: string | null; feedTypeName: string | null; quantity: string; totalPrice: string; paymentType: string }>;
  purchases: Array<{ id: number; supplierName: string | null; materialName: string | null; quantity: string; totalPrice: string; paymentType: string }>;
  manufacturing: Array<{ id: number; feedTypeName: string | null; quantityTons: string }>;
  workers: Array<{ 
    id: number; 
    taskType: string; 
    workerCount: number; 
    tonsMade: string | null; 
    pricePerTon: string | null; 
    totalAmount: string | null;
    workers: Array<{ workerId: number | null; workerName: string | null; amountEarned: string | null }>;
  }>;
  expenses: Array<{ id: number; description: string; amount: string; category: string | null }>;
  receipts: Array<{ id: number; customerName: string | null; type: string; amount: string }>;
  treasuryBalance: string;
}

export default function DailySection() {
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [data, setData] = useState<DailyData | null>(null);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    const res = await fetch(`/api/daily?date=${date}`);
    const d = await res.json();
    setData(d);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, [date]);

  const totalSalesCash = data?.sales.filter(s => s.paymentType === "cash").reduce((sum, s) => sum + parseFloat(s.totalPrice), 0) || 0;
  const totalSalesCredit = data?.sales.filter(s => s.paymentType === "credit").reduce((sum, s) => sum + parseFloat(s.totalPrice), 0) || 0;
  const totalPurchasesCash = data?.purchases.filter(p => p.paymentType === "cash").reduce((sum, p) => sum + parseFloat(p.totalPrice), 0) || 0;
  const totalPurchasesCredit = data?.purchases.filter(p => p.paymentType === "credit").reduce((sum, p) => sum + parseFloat(p.totalPrice), 0) || 0;
  const totalWorkersCost = data?.workers.reduce((sum, w) => sum + parseFloat(w.totalAmount || "0"), 0) || 0;
  const totalExpenses = data?.expenses.reduce((sum, e) => sum + parseFloat(e.amount), 0) || 0;
  const totalReceipts = data?.receipts.filter(r => r.type === "receipt").reduce((sum, r) => sum + parseFloat(r.amount), 0) || 0;
  const totalManufactured = data?.manufacturing.reduce((sum, m) => sum + parseFloat(m.quantityTons), 0) || 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-10 h-10 border-4 border-primary-light border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Date Picker */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-4 flex-wrap">
          <label className="font-bold text-lg text-slate-700">📅 تاريخ اليومية:</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="px-4 py-2 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none text-lg"
          />
          <button
            onClick={() => setDate(new Date().toISOString().split("T")[0])}
            className="px-4 py-2 bg-primary text-white rounded-xl text-sm font-medium hover:bg-primary-dark transition-colors"
          >
            اليوم
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <SummaryCard title="إجمالي المبيعات" value={totalSalesCash + totalSalesCredit} icon="💰" color="bg-green-50 text-green-700" subtitle={`نقدي: ${totalSalesCash.toLocaleString()} | آجل: ${totalSalesCredit.toLocaleString()}`} />
        <SummaryCard title="إجمالي المشتريات" value={totalPurchasesCash + totalPurchasesCredit} icon="🛒" color="bg-red-50 text-red-700" subtitle={`نقدي: ${totalPurchasesCash.toLocaleString()} | آجل: ${totalPurchasesCredit.toLocaleString()}`} />
        <SummaryCard title="تحصيلات العملاء" value={totalReceipts} icon="💵" color="bg-blue-50 text-blue-700" subtitle={`${data?.receipts.filter(r => r.type === "receipt").length || 0} سند قبض`} />
        <SummaryCard title="رصيد الخزنة" value={parseFloat(data?.treasuryBalance || "0")} icon="🏦" color="bg-purple-50 text-purple-700" subtitle="الرصيد الحالي" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <SummaryCard title="إجمالي التصنيع" value={totalManufactured} icon="🏭" color="bg-amber-50 text-amber-700" subtitle="طن" isTon />
        <SummaryCard title="يومية العمال" value={totalWorkersCost} icon="👷" color="bg-orange-50 text-orange-700" subtitle={`${data?.workers.reduce((s, w) => s + w.workerCount, 0) || 0} عامل`} />
        <SummaryCard title="المصروفات" value={totalExpenses} icon="📝" color="bg-pink-50 text-pink-700" subtitle={`${data?.expenses.length || 0} بند`} />
      </div>

      {/* Sales Table */}
      {data && data.sales.length > 0 && (
        <TableCard title="💰 المبيعات" headers={["العميل", "نوع العلف", "الكمية (طن)", "الإجمالي", "نوع الدفع"]}>
          {data.sales.map((s) => (
            <tr key={s.id} className="border-b border-slate-100 hover:bg-slate-50">
              <td className="px-4 py-3">{s.customerName}</td>
              <td className="px-4 py-3">{s.feedTypeName}</td>
              <td className="px-4 py-3">{s.quantity}</td>
              <td className="px-4 py-3 font-bold">{parseFloat(s.totalPrice).toLocaleString()} ج.م</td>
              <td className="px-4 py-3">
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${s.paymentType === "cash" ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"}`}>
                  {s.paymentType === "cash" ? "نقدي" : "آجل"}
                </span>
              </td>
            </tr>
          ))}
        </TableCard>
      )}

      {/* Receipts Table */}
      {data && data.receipts.length > 0 && (
        <TableCard title="🧾 سندات القبض والصرف" headers={["العميل", "النوع", "المبلغ"]}>
          {data.receipts.map((r) => (
            <tr key={r.id} className="border-b border-slate-100 hover:bg-slate-50">
              <td className="px-4 py-3">{r.customerName}</td>
              <td className="px-4 py-3">
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${r.type === "receipt" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                  {r.type === "receipt" ? "سند قبض" : "سند صرف"}
                </span>
              </td>
              <td className="px-4 py-3 font-bold">{parseFloat(r.amount).toLocaleString()} ج.م</td>
            </tr>
          ))}
        </TableCard>
      )}

      {/* Purchases Table */}
      {data && data.purchases.length > 0 && (
        <TableCard title="🛒 المشتريات" headers={["المورد", "الخامة", "الكمية", "الإجمالي", "نوع الدفع"]}>
          {data.purchases.map((p) => (
            <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50">
              <td className="px-4 py-3">{p.supplierName}</td>
              <td className="px-4 py-3">{p.materialName}</td>
              <td className="px-4 py-3">{p.quantity}</td>
              <td className="px-4 py-3 font-bold">{parseFloat(p.totalPrice).toLocaleString()} ج.م</td>
              <td className="px-4 py-3">
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${p.paymentType === "cash" ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"}`}>
                  {p.paymentType === "cash" ? "نقدي" : "آجل"}
                </span>
              </td>
            </tr>
          ))}
        </TableCard>
      )}

      {/* Manufacturing Table */}
      {data && data.manufacturing.length > 0 && (
        <TableCard title="🏭 التصنيع" headers={["نوع العلف", "الكمية (طن)"]}>
          {data.manufacturing.map((m) => (
            <tr key={m.id} className="border-b border-slate-100 hover:bg-slate-50">
              <td className="px-4 py-3">{m.feedTypeName}</td>
              <td className="px-4 py-3 font-bold">{m.quantityTons} طن</td>
            </tr>
          ))}
        </TableCard>
      )}

      {/* Workers Table */}
      {data && data.workers.length > 0 && (
        <TableCard title="👷 العمال" headers={["نوع العمل", "عدد العمال", "الأطنان", "سعر الطن", "الإجمالي", "العمال المشاركين"]}>
          {data.workers.map((w) => (
            <tr key={w.id} className="border-b border-slate-100 hover:bg-slate-50">
              <td className="px-4 py-3">{w.taskType}</td>
              <td className="px-4 py-3">{w.workerCount}</td>
              <td className="px-4 py-3">{w.tonsMade}</td>
              <td className="px-4 py-3">{w.pricePerTon} ج.م</td>
              <td className="px-4 py-3 font-bold">{parseFloat(w.totalAmount || "0").toLocaleString()} ج.م</td>
              <td className="px-4 py-3">
                <div className="flex flex-wrap gap-1">
                  {w.workers.map((worker, idx) => (
                    <span key={idx} className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">
                      {worker.workerName} ({parseFloat(worker.amountEarned || "0").toLocaleString()})
                    </span>
                  ))}
                </div>
              </td>
            </tr>
          ))}
        </TableCard>
      )}

      {/* Expenses Table */}
      {data && data.expenses.length > 0 && (
        <TableCard title="📝 المصروفات" headers={["البيان", "التصنيف", "المبلغ"]}>
          {data.expenses.map((e) => (
            <tr key={e.id} className="border-b border-slate-100 hover:bg-slate-50">
              <td className="px-4 py-3">{e.description}</td>
              <td className="px-4 py-3">{e.category || "-"}</td>
              <td className="px-4 py-3 font-bold">{parseFloat(e.amount).toLocaleString()} ج.م</td>
            </tr>
          ))}
        </TableCard>
      )}

      {/* Empty state */}
      {data && data.sales.length === 0 && data.purchases.length === 0 && data.manufacturing.length === 0 && data.workers.length === 0 && data.expenses.length === 0 && data.receipts.length === 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-12 text-center">
          <span className="text-6xl mb-4 block">📭</span>
          <h3 className="text-xl font-bold text-slate-600 mb-2">لا توجد بيانات لهذا اليوم</h3>
          <p className="text-slate-400">ابدأ بإضافة بيانات من الأقسام المختلفة</p>
        </div>
      )}
    </div>
  );
}

function SummaryCard({ title, value, icon, color, subtitle, isTon }: {
  title: string; value: number; icon: string; color: string; subtitle: string; isTon?: boolean;
}) {
  return (
    <div className={`rounded-2xl p-5 ${color} border border-slate-100`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-2xl">{icon}</span>
      </div>
      <p className="text-sm font-medium opacity-80">{title}</p>
      <p className="text-2xl font-black mt-1">
        {value.toLocaleString()} {isTon ? "طن" : "ج.م"}
      </p>
      <p className="text-xs mt-1 opacity-60">{subtitle}</p>
    </div>
  );
}

function TableCard({ title, headers, children }: {
  title: string; headers: string[]; children: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
        <h3 className="font-bold text-lg text-slate-700">{title}</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              {headers.map((h) => (
                <th key={h} className="px-4 py-3 text-right font-bold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>{children}</tbody>
        </table>
      </div>
    </div>
  );
}
