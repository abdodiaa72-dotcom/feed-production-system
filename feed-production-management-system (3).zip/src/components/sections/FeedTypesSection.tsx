"use client";

import { useState, useEffect, useCallback } from "react";

interface FeedType { id: number; name: string; category: string | null; pricePerTon: string | null; stockQuantity: string | null; }

export default function FeedTypesSection() {
  const [feedTypes, setFeedTypes] = useState<FeedType[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", category: "", pricePerTon: "0", stockQuantity: "0" });

  const load = useCallback(async () => {
    const data = await fetch("/api/feed-types").then(r => r.json());
    setFeedTypes(data);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/feed-types", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setForm({ name: "", category: "", pricePerTon: "0", stockQuantity: "0" });
    setShowForm(false);
    load();
  };

  const categories = ["فطام", "17%", "19%", "21%", "تسمين", "ناشئ", "بياض", "أخرى"];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-700">أصناف العلف</h2>
        <button onClick={() => setShowForm(!showForm)} className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors">
          {showForm ? "إلغاء" : "➕ صنف جديد"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
          <h3 className="font-bold text-lg mb-4 text-slate-700">إضافة صنف علف جديد</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">اسم الصنف</label>
              <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" placeholder="مثال: علف فطام 20%" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">التصنيف</label>
              <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="">اختر التصنيف</option>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">سعر الطن</label>
              <input type="number" step="0.01" value={form.pricePerTon} onChange={e => setForm({ ...form, pricePerTon: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">المخزون (طن)</label>
              <input type="number" step="0.01" value={form.stockQuantity} onChange={e => setForm({ ...form, stockQuantity: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
          </div>
          <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">حفظ</button>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {feedTypes.map(f => {
          const stock = parseFloat(f.stockQuantity || "0");
          const isLow = stock < 5;
          return (
            <div key={f.id} className={`bg-white rounded-2xl shadow-sm border-2 p-5 hover:shadow-md transition-shadow ${isLow ? "border-orange-300" : "border-slate-200"}`}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center text-xl">🌾</div>
                  <div>
                    <h3 className="font-bold text-slate-800">{f.name}</h3>
                    {f.category && <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-lg text-xs font-bold">{f.category}</span>}
                  </div>
                </div>
                {isLow && <span className="px-2 py-1 bg-orange-100 text-orange-600 rounded-lg text-xs font-bold">⚠️ قليل</span>}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-50 p-3 rounded-xl">
                  <p className="text-xs text-slate-500">المخزون</p>
                  <p className={`text-xl font-black ${isLow ? "text-orange-600" : "text-emerald-600"}`}>{stock.toLocaleString()}</p>
                  <p className="text-xs text-slate-400">طن</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl">
                  <p className="text-xs text-slate-500">سعر الطن</p>
                  <p className="text-xl font-black text-slate-700">{parseFloat(f.pricePerTon || "0").toLocaleString()}</p>
                  <p className="text-xs text-slate-400">ج.م</p>
                </div>
              </div>
            </div>
          );
        })}
        {feedTypes.length === 0 && (
          <div className="col-span-full bg-white rounded-2xl shadow-sm border border-slate-200 p-12 text-center">
            <span className="text-4xl mb-3 block">🌾</span>
            <p className="text-slate-400">لا يوجد أصناف علف بعد</p>
          </div>
        )}
      </div>
    </div>
  );
}
