"use client";

import { useState, useEffect, useCallback } from "react";

interface Purchase {
  id: number; supplierName: string | null; materialName: string | null;
  quantity: string; pricePerUnit: string; totalPrice: string;
  paymentType: string; date: string; notes: string | null;
}
interface Supplier { id: number; name: string; }
interface Material { id: number; name: string; unit: string | null; }

export default function PurchasesSection() {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    supplierId: "", materialId: "", quantity: "", pricePerUnit: "",
    paymentType: "cash", date: new Date().toISOString().split("T")[0], notes: "",
  });

  const load = useCallback(async () => {
    const [p, s, m] = await Promise.all([
      fetch("/api/purchases").then(r => r.json()),
      fetch("/api/suppliers").then(r => r.json()),
      fetch("/api/materials").then(r => r.json()),
    ]);
    setPurchases(p); setSuppliers(s); setMaterials(m);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/purchases", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        supplierId: parseInt(form.supplierId),
        materialId: parseInt(form.materialId),
      }),
    });
    setForm({ supplierId: "", materialId: "", quantity: "", pricePerUnit: "", paymentType: "cash", date: new Date().toISOString().split("T")[0], notes: "" });
    setShowForm(false);
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-700">سجل المشتريات</h2>
        <button onClick={() => setShowForm(!showForm)} className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors">
          {showForm ? "إلغاء" : "➕ شراء جديد"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
          <h3 className="font-bold text-lg mb-4 text-slate-700">عملية شراء جديدة</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">المورد</label>
              <select value={form.supplierId} onChange={e => setForm({ ...form, supplierId: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="">اختر المورد</option>
                {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">الخامة</label>
              <select value={form.materialId} onChange={e => setForm({ ...form, materialId: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="">اختر الخامة</option>
                {materials.map(m => <option key={m.id} value={m.id}>{m.name} ({m.unit})</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">الكمية</label>
              <input type="number" step="0.01" value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">سعر الوحدة</label>
              <input type="number" step="0.01" value={form.pricePerUnit} onChange={e => setForm({ ...form, pricePerUnit: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">نوع الدفع</label>
              <select value={form.paymentType} onChange={e => setForm({ ...form, paymentType: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="cash">نقدي (كاش)</option>
                <option value="credit">آجل</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">التاريخ</label>
              <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div className="md:col-span-2 lg:col-span-3">
              <label className="block text-sm font-semibold text-slate-600 mb-1">ملاحظات</label>
              <input type="text" value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
          </div>
          {form.quantity && form.pricePerUnit && (
            <div className="mt-4 p-3 bg-blue-50 rounded-xl text-blue-700 font-bold text-lg">
              الإجمالي: {(parseFloat(form.quantity) * parseFloat(form.pricePerUnit)).toLocaleString()} ج.م
            </div>
          )}
          <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">
            حفظ عملية الشراء
          </button>
        </form>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-4 py-3 text-right font-bold text-slate-600">#</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">التاريخ</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">المورد</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">الخامة</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">الكمية</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">سعر الوحدة</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">الإجمالي</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">الدفع</th>
              </tr>
            </thead>
            <tbody>
              {purchases.map((p, i) => (
                <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 text-slate-500">{i + 1}</td>
                  <td className="px-4 py-3">{p.date}</td>
                  <td className="px-4 py-3 font-medium">{p.supplierName}</td>
                  <td className="px-4 py-3">{p.materialName}</td>
                  <td className="px-4 py-3">{p.quantity}</td>
                  <td className="px-4 py-3">{parseFloat(p.pricePerUnit).toLocaleString()}</td>
                  <td className="px-4 py-3 font-bold text-red-700">{parseFloat(p.totalPrice).toLocaleString()} ج.م</td>
                  <td className="px-4 py-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${p.paymentType === "cash" ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"}`}>
                      {p.paymentType === "cash" ? "نقدي" : "آجل"}
                    </span>
                  </td>
                </tr>
              ))}
              {purchases.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-8 text-center text-slate-400">لا توجد مشتريات بعد</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
