"use client";

import { useState, useEffect, useCallback } from "react";

interface Expense { id: number; description: string; amount: string; category: string | null; date: string; notes: string | null; }

export default function ExpensesSection() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    description: "", amount: "", category: "",
    date: new Date().toISOString().split("T")[0], notes: "",
  });

  const load = useCallback(async () => {
    const data = await fetch("/api/expenses").then(r => r.json());
    setExpenses(data);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/expenses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setForm({ description: "", amount: "", category: "", date: new Date().toISOString().split("T")[0], notes: "" });
    setShowForm(false);
    load();
  };

  const totalExpenses = expenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);
  const categories = ["كهرباء", "مياه", "صيانة", "نقل", "إيجار", "وقود", "مرتبات", "أخرى"];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-700">سجل المصروفات</h2>
          <p className="text-sm text-slate-500 mt-1">إجمالي المصروفات: <span className="font-bold text-red-600">{totalExpenses.toLocaleString()} ج.م</span></p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors">
          {showForm ? "إلغاء" : "➕ مصروف جديد"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
          <h3 className="font-bold text-lg mb-4 text-slate-700">إضافة مصروف</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="lg:col-span-2">
              <label className="block text-sm font-semibold text-slate-600 mb-1">البيان</label>
              <input type="text" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" placeholder="وصف المصروف" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">المبلغ</label>
              <input type="number" step="0.01" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">التصنيف</label>
              <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="">اختر التصنيف</option>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">التاريخ</label>
              <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div className="lg:col-span-3">
              <label className="block text-sm font-semibold text-slate-600 mb-1">ملاحظات</label>
              <input type="text" value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
          </div>
          <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">حفظ</button>
        </form>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-4 py-3 text-right font-bold text-slate-600">#</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">التاريخ</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">البيان</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">التصنيف</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">المبلغ</th>
              </tr>
            </thead>
            <tbody>
              {expenses.map((e, i) => (
                <tr key={e.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 text-slate-500">{i + 1}</td>
                  <td className="px-4 py-3">{e.date}</td>
                  <td className="px-4 py-3 font-medium">{e.description}</td>
                  <td className="px-4 py-3">
                    {e.category ? <span className="px-2 py-1 bg-slate-100 rounded-lg text-xs font-bold">{e.category}</span> : "-"}
                  </td>
                  <td className="px-4 py-3 font-bold text-red-700">{parseFloat(e.amount).toLocaleString()} ج.م</td>
                </tr>
              ))}
              {expenses.length === 0 && (
                <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400">لا يوجد مصروفات بعد</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
