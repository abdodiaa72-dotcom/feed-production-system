"use client";

import { useState, useEffect, useCallback } from "react";

interface TreasuryEntry {
  id: number; date: string; description: string;
  amountIn: string | null; amountOut: string | null;
  balance: string | null; referenceType: string | null;
}

export default function TreasurySection() {
  const [transactions, setTransactions] = useState<TreasuryEntry[]>([]);
  const [currentBalance, setCurrentBalance] = useState("0");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    date: new Date().toISOString().split("T")[0],
    description: "", amountIn: "0", amountOut: "0",
  });

  const load = useCallback(async () => {
    const data = await fetch("/api/treasury").then(r => r.json());
    setTransactions(data.transactions);
    setCurrentBalance(data.currentBalance);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/treasury", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, referenceType: "manual" }),
    });
    setForm({ date: new Date().toISOString().split("T")[0], description: "", amountIn: "0", amountOut: "0" });
    setShowForm(false);
    load();
  };

  const totalIn = transactions.reduce((sum, t) => sum + parseFloat(t.amountIn || "0"), 0);
  const totalOut = transactions.reduce((sum, t) => sum + parseFloat(t.amountOut || "0"), 0);

  return (
    <div className="space-y-6">
      {/* Balance Card */}
      <div className="bg-gradient-to-l from-primary to-primary-light rounded-2xl p-8 text-white shadow-lg">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <p className="text-blue-100 text-sm font-medium">رصيد الخزنة الحالي</p>
            <p className="text-4xl font-black mt-2">{parseFloat(currentBalance).toLocaleString()} ج.م</p>
          </div>
          <div className="flex gap-6">
            <div className="text-center">
              <p className="text-blue-100 text-xs">إجمالي الوارد</p>
              <p className="text-xl font-bold text-green-200">↑ {totalIn.toLocaleString()}</p>
            </div>
            <div className="text-center">
              <p className="text-blue-100 text-xs">إجمالي المنصرف</p>
              <p className="text-xl font-bold text-red-200">↓ {totalOut.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-700">حركات الخزنة</h2>
        <button onClick={() => setShowForm(!showForm)} className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors">
          {showForm ? "إلغاء" : "➕ حركة يدوية"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
          <h3 className="font-bold text-lg mb-4 text-slate-700">إضافة حركة يدوية</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">التاريخ</label>
              <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">البيان</label>
              <input type="text" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">وارد (إيداع)</label>
              <input type="number" step="0.01" value={form.amountIn} onChange={e => setForm({ ...form, amountIn: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">منصرف (سحب)</label>
              <input type="number" step="0.01" value={form.amountOut} onChange={e => setForm({ ...form, amountOut: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
          </div>
          <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">حفظ</button>
        </form>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-4 py-3 text-right font-bold text-slate-600">#</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">التاريخ</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">البيان</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">وارد</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">منصرف</th>
                <th className="px-4 py-3 text-right font-bold text-slate-600">النوع</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((t, i) => (
                <tr key={t.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 text-slate-500">{i + 1}</td>
                  <td className="px-4 py-3">{t.date}</td>
                  <td className="px-4 py-3 font-medium">{t.description}</td>
                  <td className="px-4 py-3 font-bold text-green-700">
                    {parseFloat(t.amountIn || "0") > 0 ? `+${parseFloat(t.amountIn || "0").toLocaleString()}` : "-"}
                  </td>
                  <td className="px-4 py-3 font-bold text-red-700">
                    {parseFloat(t.amountOut || "0") > 0 ? `-${parseFloat(t.amountOut || "0").toLocaleString()}` : "-"}
                  </td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-1 bg-slate-100 rounded-lg text-xs font-bold">{t.referenceType || "يدوي"}</span>
                  </td>
                </tr>
              ))}
              {transactions.length === 0 && (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400">لا يوجد حركات بعد</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
