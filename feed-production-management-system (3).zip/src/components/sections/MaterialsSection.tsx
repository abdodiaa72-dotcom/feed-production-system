"use client";

import { useState, useEffect, useCallback } from "react";

interface Material { id: number; name: string; unit: string | null; quantity: string | null; pricePerUnit: string | null; }

export default function MaterialsSection() {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [adjustForm, setAdjustForm] = useState({ id: 0, adjustment: "", type: "add" });
  const [form, setForm] = useState({ name: "", unit: "كجم", quantity: "0", pricePerUnit: "0" });

  const load = useCallback(async () => {
    const data = await fetch("/api/materials").then(r => r.json());
    setMaterials(data);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/materials", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setForm({ name: "", unit: "كجم", quantity: "0", pricePerUnit: "0" });
    setShowForm(false);
    load();
  };

  const handleAdjust = async (e: React.FormEvent) => {
    e.preventDefault();
    const mat = materials.find(m => m.id === adjustForm.id);
    if (!mat) return;
    const currentQty = parseFloat(mat.quantity || "0");
    const adj = parseFloat(adjustForm.adjustment);
    const newQty = adjustForm.type === "add" ? currentQty + adj : currentQty - adj;

    await fetch("/api/materials", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: adjustForm.id, name: mat.name, unit: mat.unit, quantity: newQty.toString(), pricePerUnit: mat.pricePerUnit }),
    });
    setEditingId(null);
    setAdjustForm({ id: 0, adjustment: "", type: "add" });
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h2 className="text-xl font-bold text-slate-700">إدارة الخامات والمواد</h2>
        <button onClick={() => setShowForm(!showForm)} className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors">
          {showForm ? "إلغاء" : "➕ خامة جديدة"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
          <h3 className="font-bold text-lg mb-4 text-slate-700">إضافة خامة جديدة</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">اسم الخامة</label>
              <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">الوحدة</label>
              <select value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                <option value="كجم">كجم</option>
                <option value="طن">طن</option>
                <option value="لتر">لتر</option>
                <option value="كيس">كيس</option>
                <option value="قطعة">قطعة</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">الكمية الحالية</label>
              <input type="number" step="0.01" value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">سعر الوحدة</label>
              <input type="number" step="0.01" value={form.pricePerUnit} onChange={e => setForm({ ...form, pricePerUnit: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
            </div>
          </div>
          <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">حفظ</button>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {materials.map(m => {
          const qty = parseFloat(m.quantity || "0");
          const isLow = qty < 100;
          return (
            <div key={m.id} className={`bg-white rounded-2xl shadow-sm border-2 p-5 hover:shadow-md transition-shadow ${isLow ? "border-red-300" : "border-slate-200"}`}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${isLow ? "bg-red-100" : "bg-emerald-100"}`}>📦</div>
                  <div>
                    <h3 className="font-bold text-slate-800">{m.name}</h3>
                    <p className="text-xs text-slate-500">الوحدة: {m.unit}</p>
                  </div>
                </div>
                {isLow && <span className="px-2 py-1 bg-red-100 text-red-600 rounded-lg text-xs font-bold">⚠️ منخفض</span>}
              </div>

              <div className="grid grid-cols-2 gap-3 mb-3">
                <div className="bg-slate-50 p-3 rounded-xl">
                  <p className="text-xs text-slate-500">الكمية</p>
                  <p className={`text-xl font-black ${isLow ? "text-red-600" : "text-emerald-600"}`}>{qty.toLocaleString()}</p>
                  <p className="text-xs text-slate-400">{m.unit}</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl">
                  <p className="text-xs text-slate-500">سعر الوحدة</p>
                  <p className="text-xl font-black text-slate-700">{parseFloat(m.pricePerUnit || "0").toLocaleString()}</p>
                  <p className="text-xs text-slate-400">ج.م</p>
                </div>
              </div>

              {editingId === m.id ? (
                <form onSubmit={handleAdjust} className="space-y-2 fade-in">
                  <div className="flex gap-2">
                    <select value={adjustForm.type} onChange={e => setAdjustForm({ ...adjustForm, type: e.target.value })} className="px-3 py-2 rounded-lg border border-slate-200 text-sm">
                      <option value="add">➕ زيادة</option>
                      <option value="subtract">➖ نقص</option>
                    </select>
                    <input type="number" step="0.01" value={adjustForm.adjustment} onChange={e => setAdjustForm({ ...adjustForm, adjustment: e.target.value })} placeholder="الكمية" required className="flex-1 px-3 py-2 rounded-lg border border-slate-200 text-sm" />
                  </div>
                  <div className="flex gap-2">
                    <button type="submit" className="flex-1 px-3 py-2 bg-primary text-white rounded-lg text-sm font-bold">حفظ</button>
                    <button type="button" onClick={() => setEditingId(null)} className="px-3 py-2 bg-slate-200 rounded-lg text-sm">إلغاء</button>
                  </div>
                </form>
              ) : (
                <button
                  onClick={() => { setEditingId(m.id); setAdjustForm({ id: m.id, adjustment: "", type: "add" }); }}
                  className="w-full px-3 py-2 bg-blue-50 text-blue-700 rounded-xl text-sm font-bold hover:bg-blue-100 transition-colors"
                >
                  ⚙️ تعديل الكمية
                </button>
              )}
            </div>
          );
        })}
        {materials.length === 0 && (
          <div className="col-span-full bg-white rounded-2xl shadow-sm border border-slate-200 p-12 text-center">
            <span className="text-4xl mb-3 block">📦</span>
            <p className="text-slate-400">لا يوجد خامات بعد</p>
          </div>
        )}
      </div>
    </div>
  );
}
