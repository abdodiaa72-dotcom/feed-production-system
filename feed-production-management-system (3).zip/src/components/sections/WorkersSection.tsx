"use client";

import { useState, useEffect, useCallback } from "react";

interface Worker {
  id: number;
  name: string;
  phone: string | null;
  nationalId: string | null;
  address: string | null;
  dailyRate: string | null;
  balance: string | null;
  isActive: boolean | null;
}

interface DailyWorkRecord {
  id: number;
  date: string;
  taskType: string;
  tonsMade: string | null;
  pricePerTon: string | null;
  totalAmount: string | null;
  notes: string | null;
  workers: Array<{
    id: number;
    workerId: number | null;
    workerName: string | null;
    amountEarned: string | null;
  }>;
}

interface WorkerPayment {
  id: number;
  workerId: number | null;
  workerName: string | null;
  type: string;
  amount: string;
  date: string;
  notes: string | null;
}

export default function WorkersSection() {
  const [activeTab, setActiveTab] = useState<"workers" | "daily" | "payments">("workers");
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [dailyRecords, setDailyRecords] = useState<DailyWorkRecord[]>([]);
  const [payments, setPayments] = useState<WorkerPayment[]>([]);
  
  // Forms
  const [showWorkerForm, setShowWorkerForm] = useState(false);
  const [showDailyForm, setShowDailyForm] = useState(false);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  
  const [workerForm, setWorkerForm] = useState({
    name: "", phone: "", nationalId: "", address: "", dailyRate: ""
  });
  
  const [dailyForm, setDailyForm] = useState({
    date: new Date().toISOString().split("T")[0],
    taskType: "تصنيع",
    tonsMade: "",
    pricePerTon: "",
    notes: "",
    selectedWorkers: [] as string[],
  });
  
  const [paymentForm, setPaymentForm] = useState({
    workerId: "",
    type: "payment",
    amount: "",
    date: new Date().toISOString().split("T")[0],
    notes: "",
  });

  const load = useCallback(async () => {
    const [w, d, p] = await Promise.all([
      fetch("/api/workers-list").then(r => r.json()),
      fetch("/api/daily-work").then(r => r.json()),
      fetch("/api/worker-payments").then(r => r.json()),
    ]);
    setWorkers(w);
    setDailyRecords(d);
    setPayments(p);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleAddWorker = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/workers-list", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(workerForm),
    });
    setWorkerForm({ name: "", phone: "", nationalId: "", address: "", dailyRate: "" });
    setShowWorkerForm(false);
    load();
  };

  const handleAddDaily = async (e: React.FormEvent) => {
    e.preventDefault();
    const totalAmount = dailyForm.tonsMade && dailyForm.pricePerTon
      ? (parseFloat(dailyForm.tonsMade) * parseFloat(dailyForm.pricePerTon)).toFixed(2)
      : "0";
    
    await fetch("/api/daily-work", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...dailyForm,
        totalAmount,
        workers: dailyForm.selectedWorkers,
      }),
    });
    setDailyForm({
      date: new Date().toISOString().split("T")[0],
      taskType: "تصنيع", tonsMade: "", pricePerTon: "", notes: "",
      selectedWorkers: [],
    });
    setShowDailyForm(false);
    load();
  };

  const handleAddPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/worker-payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(paymentForm),
    });
    setPaymentForm({
      workerId: "", type: "payment", amount: "",
      date: new Date().toISOString().split("T")[0], notes: "",
    });
    setShowPaymentForm(false);
    load();
  };

  const toggleWorkerSelection = (workerId: string) => {
    setDailyForm(f => ({
      ...f,
      selectedWorkers: f.selectedWorkers.includes(workerId)
        ? f.selectedWorkers.filter(id => id !== workerId)
        : [...f.selectedWorkers, workerId]
    }));
  };

  const totalBalance = workers.reduce((sum, w) => sum + parseFloat(w.balance || "0"), 0);
  const activeWorkers = workers.filter(w => w.isActive);

  const calcDailyTotal = dailyForm.tonsMade && dailyForm.pricePerTon
    ? parseFloat(dailyForm.tonsMade) * parseFloat(dailyForm.pricePerTon)
    : 0;
  const calcPerWorker = dailyForm.selectedWorkers.length > 0
    ? calcDailyTotal / dailyForm.selectedWorkers.length
    : 0;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-l from-blue-600 to-blue-500 rounded-2xl p-5 text-white">
          <p className="text-blue-100 text-sm">إجمالي العمال</p>
          <p className="text-3xl font-black mt-1">{activeWorkers.length}</p>
          <p className="text-blue-200 text-xs mt-1">عامل نشط</p>
        </div>
        <div className="bg-gradient-to-l from-amber-600 to-amber-500 rounded-2xl p-5 text-white">
          <p className="text-amber-100 text-sm">إجمالي المستحقات</p>
          <p className="text-3xl font-black mt-1">{totalBalance.toLocaleString()}</p>
          <p className="text-amber-200 text-xs mt-1">ج.م للعمال</p>
        </div>
        <div className="bg-gradient-to-l from-emerald-600 to-emerald-500 rounded-2xl p-5 text-white">
          <p className="text-emerald-100 text-sm">عمليات اليوم</p>
          <p className="text-3xl font-black mt-1">
            {dailyRecords.filter(d => d.date === new Date().toISOString().split("T")[0]).length}
          </p>
          <p className="text-emerald-200 text-xs mt-1">عملية تصنيع</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-1 flex gap-1">
        {[
          { key: "workers", label: "👷 قائمة العمال" },
          { key: "daily", label: "📋 سجل العمل اليومي" },
          { key: "payments", label: "💵 سندات القبض والصرف" },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as typeof activeTab)}
            className={`flex-1 py-3 px-4 rounded-xl font-bold text-sm transition-all ${
              activeTab === tab.key
                ? "bg-primary text-white"
                : "text-slate-600 hover:bg-slate-100"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Workers List Tab */}
      {activeTab === "workers" && (
        <div className="space-y-4 fade-in">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-lg text-slate-700">قائمة العمال</h3>
            <button
              onClick={() => setShowWorkerForm(!showWorkerForm)}
              className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors"
            >
              {showWorkerForm ? "إلغاء" : "➕ إضافة عامل"}
            </button>
          </div>

          {showWorkerForm && (
            <form onSubmit={handleAddWorker} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
              <h4 className="font-bold text-lg mb-4 text-slate-700">إضافة عامل جديد</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">اسم العامل *</label>
                  <input type="text" value={workerForm.name} onChange={e => setWorkerForm({ ...workerForm, name: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">رقم الهاتف</label>
                  <input type="text" value={workerForm.phone} onChange={e => setWorkerForm({ ...workerForm, phone: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">الرقم القومي</label>
                  <input type="text" value={workerForm.nationalId} onChange={e => setWorkerForm({ ...workerForm, nationalId: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">الأجر اليومي</label>
                  <input type="number" step="0.01" value={workerForm.dailyRate} onChange={e => setWorkerForm({ ...workerForm, dailyRate: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">العنوان</label>
                  <input type="text" value={workerForm.address} onChange={e => setWorkerForm({ ...workerForm, address: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
                </div>
              </div>
              <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">حفظ العامل</button>
            </form>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {workers.map(w => (
              <div key={w.id} className={`bg-white rounded-2xl shadow-sm border-2 p-5 hover:shadow-md transition-shadow ${w.isActive ? "border-slate-200" : "border-red-200 opacity-60"}`}>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-xl">👷</div>
                  <div className="flex-1">
                    <h4 className="font-bold text-slate-800">{w.name}</h4>
                    {w.phone && <p className="text-sm text-slate-500">📱 {w.phone}</p>}
                  </div>
                  {!w.isActive && <span className="px-2 py-1 bg-red-100 text-red-600 rounded-lg text-xs font-bold">غير نشط</span>}
                </div>
                
                {w.nationalId && <p className="text-xs text-slate-400 mb-2">🆔 {w.nationalId}</p>}
                
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-slate-50 p-3 rounded-xl">
                    <p className="text-xs text-slate-500">الأجر اليومي</p>
                    <p className="text-lg font-bold text-slate-700">{parseFloat(w.dailyRate || "0").toLocaleString()}</p>
                  </div>
                  <div className={`p-3 rounded-xl ${parseFloat(w.balance || "0") > 0 ? "bg-green-50" : parseFloat(w.balance || "0") < 0 ? "bg-red-50" : "bg-slate-50"}`}>
                    <p className="text-xs text-slate-500">المستحقات</p>
                    <p className={`text-lg font-bold ${parseFloat(w.balance || "0") > 0 ? "text-green-600" : parseFloat(w.balance || "0") < 0 ? "text-red-600" : "text-slate-600"}`}>
                      {parseFloat(w.balance || "0").toLocaleString()} ج.م
                    </p>
                  </div>
                </div>
              </div>
            ))}
            {workers.length === 0 && (
              <div className="col-span-full bg-white rounded-2xl shadow-sm border border-slate-200 p-12 text-center">
                <span className="text-4xl mb-3 block">👷</span>
                <p className="text-slate-400">لا يوجد عمال بعد - أضف العمال أولاً</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Daily Work Tab */}
      {activeTab === "daily" && (
        <div className="space-y-4 fade-in">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-lg text-slate-700">سجل العمل اليومي</h3>
            <button
              onClick={() => setShowDailyForm(!showDailyForm)}
              className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors"
            >
              {showDailyForm ? "إلغاء" : "➕ تسجيل عمل يومي"}
            </button>
          </div>

          {showDailyForm && (
            <form onSubmit={handleAddDaily} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
              <h4 className="font-bold text-lg mb-4 text-slate-700">تسجيل عمل يومي جديد</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">التاريخ</label>
                  <input type="date" value={dailyForm.date} onChange={e => setDailyForm({ ...dailyForm, date: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">نوع العمل</label>
                  <select value={dailyForm.taskType} onChange={e => setDailyForm({ ...dailyForm, taskType: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                    <option value="تصنيع">تصنيع</option>
                    <option value="تعتيق">تعتيق</option>
                    <option value="تحميل">تحميل</option>
                    <option value="تفريغ">تفريغ</option>
                    <option value="أخرى">أخرى</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">عدد الأطنان</label>
                  <input type="number" step="0.01" value={dailyForm.tonsMade} onChange={e => setDailyForm({ ...dailyForm, tonsMade: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">سعر الطن</label>
                  <input type="number" step="0.01" value={dailyForm.pricePerTon} onChange={e => setDailyForm({ ...dailyForm, pricePerTon: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
                </div>
              </div>

              {/* Worker Selection */}
              <div className="mt-4">
                <label className="block text-sm font-semibold text-slate-600 mb-2">العمال المشاركين (اختر من القائمة)</label>
                <div className="flex flex-wrap gap-2 p-4 bg-slate-50 rounded-xl max-h-48 overflow-y-auto">
                  {activeWorkers.map(w => (
                    <button
                      key={w.id}
                      type="button"
                      onClick={() => toggleWorkerSelection(w.id.toString())}
                      className={`px-4 py-2 rounded-xl font-medium text-sm transition-all ${
                        dailyForm.selectedWorkers.includes(w.id.toString())
                          ? "bg-primary text-white"
                          : "bg-white border border-slate-200 text-slate-700 hover:border-primary"
                      }`}
                    >
                      {dailyForm.selectedWorkers.includes(w.id.toString()) && "✓ "}
                      {w.name}
                    </button>
                  ))}
                  {activeWorkers.length === 0 && (
                    <p className="text-slate-400 text-sm">لا يوجد عمال - أضف العمال أولاً من تبويب &quot;قائمة العمال&quot;</p>
                  )}
                </div>
                <p className="text-sm text-slate-500 mt-2">تم اختيار {dailyForm.selectedWorkers.length} عامل</p>
              </div>

              {/* Calculation Summary */}
              {(dailyForm.tonsMade || dailyForm.pricePerTon) && (
                <div className="mt-4 p-4 bg-blue-50 rounded-xl">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-xs text-blue-600">الإجمالي</p>
                      <p className="text-xl font-black text-blue-700">{calcDailyTotal.toLocaleString()} ج.م</p>
                    </div>
                    <div>
                      <p className="text-xs text-blue-600">عدد العمال</p>
                      <p className="text-xl font-black text-blue-700">{dailyForm.selectedWorkers.length}</p>
                    </div>
                    <div>
                      <p className="text-xs text-blue-600">نصيب الفرد</p>
                      <p className="text-xl font-black text-blue-700">{calcPerWorker.toLocaleString()} ج.م</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-4">
                <label className="block text-sm font-semibold text-slate-600 mb-1">ملاحظات</label>
                <input type="text" value={dailyForm.notes} onChange={e => setDailyForm({ ...dailyForm, notes: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
              </div>

              <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">حفظ</button>
            </form>
          )}

          {/* Daily Records Table */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-4 py-3 text-right font-bold text-slate-600">التاريخ</th>
                    <th className="px-4 py-3 text-right font-bold text-slate-600">نوع العمل</th>
                    <th className="px-4 py-3 text-right font-bold text-slate-600">الأطنان</th>
                    <th className="px-4 py-3 text-right font-bold text-slate-600">سعر الطن</th>
                    <th className="px-4 py-3 text-right font-bold text-slate-600">الإجمالي</th>
                    <th className="px-4 py-3 text-right font-bold text-slate-600">العمال</th>
                  </tr>
                </thead>
                <tbody>
                  {dailyRecords.map(r => (
                    <tr key={r.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="px-4 py-3">{r.date}</td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-lg text-xs font-bold">{r.taskType}</span>
                      </td>
                      <td className="px-4 py-3">{r.tonsMade} طن</td>
                      <td className="px-4 py-3">{parseFloat(r.pricePerTon || "0").toLocaleString()} ج.م</td>
                      <td className="px-4 py-3 font-bold text-green-700">{parseFloat(r.totalAmount || "0").toLocaleString()} ج.م</td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          {r.workers.map(w => (
                            <span key={w.id} className="px-2 py-0.5 bg-slate-100 rounded text-xs">
                              {w.workerName} ({parseFloat(w.amountEarned || "0").toLocaleString()})
                            </span>
                          ))}
                        </div>
                      </td>
                    </tr>
                  ))}
                  {dailyRecords.length === 0 && (
                    <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400">لا يوجد سجلات عمل بعد</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Payments Tab */}
      {activeTab === "payments" && (
        <div className="space-y-4 fade-in">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-lg text-slate-700">سندات القبض والصرف للعمال</h3>
            <button
              onClick={() => setShowPaymentForm(!showPaymentForm)}
              className="px-6 py-2.5 bg-accent text-white rounded-xl font-bold hover:bg-accent-light transition-colors"
            >
              {showPaymentForm ? "إلغاء" : "➕ سند جديد"}
            </button>
          </div>

          {showPaymentForm && (
            <form onSubmit={handleAddPayment} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 fade-in">
              <h4 className="font-bold text-lg mb-4 text-slate-700">إضافة سند جديد</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">العامل</label>
                  <select value={paymentForm.workerId} onChange={e => setPaymentForm({ ...paymentForm, workerId: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                    <option value="">اختر العامل</option>
                    {workers.map(w => (
                      <option key={w.id} value={w.id}>
                        {w.name} (مستحقاته: {parseFloat(w.balance || "0").toLocaleString()})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">نوع السند</label>
                  <select value={paymentForm.type} onChange={e => setPaymentForm({ ...paymentForm, type: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none">
                    <option value="payment">صرف مستحقات</option>
                    <option value="advance">سلفة</option>
                    <option value="deduction">خصم</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">المبلغ</label>
                  <input type="number" step="0.01" value={paymentForm.amount} onChange={e => setPaymentForm({ ...paymentForm, amount: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">التاريخ</label>
                  <input type="date" value={paymentForm.date} onChange={e => setPaymentForm({ ...paymentForm, date: e.target.value })} required className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-600 mb-1">ملاحظات</label>
                  <input type="text" value={paymentForm.notes} onChange={e => setPaymentForm({ ...paymentForm, notes: e.target.value })} className="w-full px-4 py-2.5 rounded-xl border-2 border-slate-200 focus:border-primary-light focus:outline-none" />
                </div>
              </div>
              <button type="submit" className="mt-4 px-8 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-colors">حفظ السند</button>
            </form>
          )}

          {/* Payments Table */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-4 py-3 text-right font-bold text-slate-600">#</th>
                    <th className="px-4 py-3 text-right font-bold text-slate-600">التاريخ</th>
                    <th className="px-4 py-3 text-right font-bold text-slate-600">العامل</th>
                    <th className="px-4 py-3 text-right font-bold text-slate-600">النوع</th>
                    <th className="px-4 py-3 text-right font-bold text-slate-600">المبلغ</th>
                    <th className="px-4 py-3 text-right font-bold text-slate-600">ملاحظات</th>
                  </tr>
                </thead>
                <tbody>
                  {payments.map((p, i) => (
                    <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="px-4 py-3 text-slate-500">{i + 1}</td>
                      <td className="px-4 py-3">{p.date}</td>
                      <td className="px-4 py-3 font-medium">{p.workerName}</td>
                      <td className="px-4 py-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                          p.type === "payment" ? "bg-green-100 text-green-700" :
                          p.type === "advance" ? "bg-blue-100 text-blue-700" :
                          "bg-red-100 text-red-700"
                        }`}>
                          {p.type === "payment" ? "صرف" : p.type === "advance" ? "سلفة" : "خصم"}
                        </span>
                      </td>
                      <td className={`px-4 py-3 font-bold ${p.type === "deduction" ? "text-red-700" : "text-green-700"}`}>
                        {parseFloat(p.amount).toLocaleString()} ج.م
                      </td>
                      <td className="px-4 py-3 text-slate-500">{p.notes || "-"}</td>
                    </tr>
                  ))}
                  {payments.length === 0 && (
                    <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400">لا يوجد سندات بعد</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
