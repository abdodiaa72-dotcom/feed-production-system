import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "نظام إدارة مصنع الأعلاف",
  description: "نظام متكامل لإدارة مصنع الأعلاف - يوميه، مبيعات، مشتريات، تصنيع، عمال، خزنة",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-surface text-slate-900 antialiased">{children}</body>
    </html>
  );
}
