import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { purchases, materials, suppliers, treasury } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export async function GET() {
  const data = await db
    .select({
      id: purchases.id,
      supplierId: purchases.supplierId,
      materialId: purchases.materialId,
      quantity: purchases.quantity,
      pricePerUnit: purchases.pricePerUnit,
      totalPrice: purchases.totalPrice,
      paymentType: purchases.paymentType,
      date: purchases.date,
      notes: purchases.notes,
      supplierName: suppliers.name,
      materialName: materials.name,
    })
    .from(purchases)
    .leftJoin(suppliers, eq(purchases.supplierId, suppliers.id))
    .leftJoin(materials, eq(purchases.materialId, materials.id))
    .orderBy(desc(purchases.id));
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const totalPrice = (
      parseFloat(body.quantity) * parseFloat(body.pricePerUnit)
    ).toFixed(2);

    const [item] = await db
      .insert(purchases)
      .values({
        supplierId: body.supplierId,
        materialId: body.materialId,
        quantity: body.quantity,
        pricePerUnit: body.pricePerUnit,
        totalPrice,
        paymentType: body.paymentType,
        date: body.date,
        notes: body.notes || null,
      })
      .returning();

    // Update material quantity
    await db
      .update(materials)
      .set({
        quantity: sql`${materials.quantity}::numeric + ${body.quantity}::numeric`,
      })
      .where(eq(materials.id, body.materialId));

    // If credit, update supplier balance
    if (body.paymentType === "credit") {
      await db
        .update(suppliers)
        .set({
          balance: sql`${suppliers.balance}::numeric + ${totalPrice}::numeric`,
        })
        .where(eq(suppliers.id, body.supplierId));
    }

    // If cash, deduct from treasury
    if (body.paymentType === "cash") {
      await db.insert(treasury).values({
        date: body.date,
        description: `شراء خامات - ${body.notes || ""}`,
        amountIn: "0",
        amountOut: totalPrice,
        balance: "0",
        referenceType: "purchase",
        referenceId: item.id,
      });
    }

    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
