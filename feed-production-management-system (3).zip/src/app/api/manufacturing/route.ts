import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  manufacturing,
  manufacturingMaterials,
  feedTypes,
  materials,
} from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export async function GET() {
  const data = await db
    .select({
      id: manufacturing.id,
      feedTypeId: manufacturing.feedTypeId,
      quantityTons: manufacturing.quantityTons,
      date: manufacturing.date,
      notes: manufacturing.notes,
      feedTypeName: feedTypes.name,
    })
    .from(manufacturing)
    .leftJoin(feedTypes, eq(manufacturing.feedTypeId, feedTypes.id))
    .orderBy(desc(manufacturing.id));
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // Create manufacturing record
    const [item] = await db
      .insert(manufacturing)
      .values({
        feedTypeId: body.feedTypeId,
        quantityTons: body.quantityTons,
        date: body.date,
        notes: body.notes || null,
      })
      .returning();

    // Add feed stock
    await db
      .update(feedTypes)
      .set({
        stockQuantity: sql`${feedTypes.stockQuantity}::numeric + ${body.quantityTons}::numeric`,
      })
      .where(eq(feedTypes.id, body.feedTypeId));

    // Deduct materials used
    if (body.materialsUsed && Array.isArray(body.materialsUsed)) {
      for (const mat of body.materialsUsed) {
        await db.insert(manufacturingMaterials).values({
          manufacturingId: item.id,
          materialId: mat.materialId,
          quantityUsed: mat.quantityUsed,
        });

        await db
          .update(materials)
          .set({
            quantity: sql`${materials.quantity}::numeric - ${mat.quantityUsed}::numeric`,
          })
          .where(eq(materials.id, mat.materialId));
      }
    }

    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
