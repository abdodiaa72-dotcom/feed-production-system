import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  sales,
  purchases,
  manufacturing,
  dailyWork,
  workerAttendance,
  workersList,
  expenses,
  treasury,
  receipts,
  customers,
  suppliers,
  feedTypes,
  materials,
} from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const date = searchParams.get("date") || new Date().toISOString().split("T")[0];

  // Sales for the day
  const daySales = await db
    .select({
      id: sales.id,
      customerId: sales.customerId,
      feedTypeId: sales.feedTypeId,
      quantity: sales.quantity,
      pricePerTon: sales.pricePerTon,
      totalPrice: sales.totalPrice,
      paymentType: sales.paymentType,
      notes: sales.notes,
      customerName: customers.name,
      feedTypeName: feedTypes.name,
    })
    .from(sales)
    .leftJoin(customers, eq(sales.customerId, customers.id))
    .leftJoin(feedTypes, eq(sales.feedTypeId, feedTypes.id))
    .where(eq(sales.date, date));

  // Purchases for the day
  const dayPurchases = await db
    .select({
      id: purchases.id,
      supplierId: purchases.supplierId,
      materialId: purchases.materialId,
      quantity: purchases.quantity,
      pricePerUnit: purchases.pricePerUnit,
      totalPrice: purchases.totalPrice,
      paymentType: purchases.paymentType,
      notes: purchases.notes,
      supplierName: suppliers.name,
      materialName: materials.name,
    })
    .from(purchases)
    .leftJoin(suppliers, eq(purchases.supplierId, suppliers.id))
    .leftJoin(materials, eq(purchases.materialId, materials.id))
    .where(eq(purchases.date, date));

  // Manufacturing for the day
  const dayManufacturing = await db
    .select({
      id: manufacturing.id,
      feedTypeId: manufacturing.feedTypeId,
      quantityTons: manufacturing.quantityTons,
      notes: manufacturing.notes,
      feedTypeName: feedTypes.name,
    })
    .from(manufacturing)
    .leftJoin(feedTypes, eq(manufacturing.feedTypeId, feedTypes.id))
    .where(eq(manufacturing.date, date));

  // Workers for the day (new system)
  const dayWorkRecords = await db
    .select({
      id: dailyWork.id,
      taskType: dailyWork.taskType,
      tonsMade: dailyWork.tonsMade,
      pricePerTon: dailyWork.pricePerTon,
      totalAmount: dailyWork.totalAmount,
      notes: dailyWork.notes,
    })
    .from(dailyWork)
    .where(eq(dailyWork.date, date));

  // Get worker attendance for each daily work record
  const dayWorkers = await Promise.all(
    dayWorkRecords.map(async (dw) => {
      const attendance = await db
        .select({
          workerId: workerAttendance.workerId,
          workerName: workersList.name,
          amountEarned: workerAttendance.amountEarned,
        })
        .from(workerAttendance)
        .leftJoin(workersList, eq(workerAttendance.workerId, workersList.id))
        .where(eq(workerAttendance.dailyWorkId, dw.id));

      return {
        ...dw,
        workerCount: attendance.length,
        workers: attendance,
      };
    })
  );

  // Expenses for the day
  const dayExpenses = await db
    .select()
    .from(expenses)
    .where(eq(expenses.date, date));

  // Receipts for the day
  const dayReceipts = await db
    .select({
      id: receipts.id,
      customerId: receipts.customerId,
      type: receipts.type,
      amount: receipts.amount,
      notes: receipts.notes,
      customerName: customers.name,
    })
    .from(receipts)
    .leftJoin(customers, eq(receipts.customerId, customers.id))
    .where(eq(receipts.date, date));

  // Treasury balance
  const totalIn = await db
    .select({
      total: sql<string>`COALESCE(SUM(${treasury.amountIn}::numeric), 0)`,
    })
    .from(treasury);
  const totalOut = await db
    .select({
      total: sql<string>`COALESCE(SUM(${treasury.amountOut}::numeric), 0)`,
    })
    .from(treasury);

  const currentBalance = (
    parseFloat(totalIn[0]?.total || "0") -
    parseFloat(totalOut[0]?.total || "0")
  ).toFixed(2);

  return NextResponse.json({
    date,
    sales: daySales,
    purchases: dayPurchases,
    manufacturing: dayManufacturing,
    workers: dayWorkers,
    expenses: dayExpenses,
    receipts: dayReceipts,
    treasuryBalance: currentBalance,
  });
}
