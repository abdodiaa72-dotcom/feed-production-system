import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { materials } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const data = await db.select().from(materials).orderBy(desc(materials.id));
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const [item] = await db
      .insert(materials)
      .values({
        name: body.name,
        unit: body.unit || "كجم",
        quantity: body.quantity || "0",
        pricePerUnit: body.pricePerUnit || "0",
      })
      .returning();
    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const [item] = await db
      .update(materials)
      .set({
        name: body.name,
        unit: body.unit,
        quantity: body.quantity,
        pricePerUnit: body.pricePerUnit,
      })
      .where(eq(materials.id, body.id))
      .returning();
    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
