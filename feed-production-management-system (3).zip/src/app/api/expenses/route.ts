import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { expenses, treasury } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  const data = await db.select().from(expenses).orderBy(desc(expenses.id));
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const [item] = await db
      .insert(expenses)
      .values({
        description: body.description,
        amount: body.amount,
        category: body.category || null,
        date: body.date,
        notes: body.notes || null,
      })
      .returning();

    // Deduct from treasury
    await db.insert(treasury).values({
      date: body.date,
      description: `مصروفات - ${body.description}`,
      amountIn: "0",
      amountOut: body.amount,
      balance: "0",
      referenceType: "expense",
      referenceId: item.id,
    });

    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
