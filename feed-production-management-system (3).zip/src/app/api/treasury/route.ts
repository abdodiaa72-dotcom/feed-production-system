import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { treasury } from "@/db/schema";
import { desc, sql } from "drizzle-orm";

export async function GET() {
  const data = await db.select().from(treasury).orderBy(desc(treasury.id));

  // Calculate running balance
  const totalIn = await db
    .select({ total: sql<string>`COALESCE(SUM(${treasury.amountIn}::numeric), 0)` })
    .from(treasury);
  const totalOut = await db
    .select({ total: sql<string>`COALESCE(SUM(${treasury.amountOut}::numeric), 0)` })
    .from(treasury);

  const currentBalance = (
    parseFloat(totalIn[0]?.total || "0") -
    parseFloat(totalOut[0]?.total || "0")
  ).toFixed(2);

  return NextResponse.json({ transactions: data, currentBalance });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const [item] = await db
      .insert(treasury)
      .values({
        date: body.date,
        description: body.description,
        amountIn: body.amountIn || "0",
        amountOut: body.amountOut || "0",
        balance: "0",
        referenceType: body.referenceType || "manual",
        referenceId: body.referenceId || null,
      })
      .returning();
    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
