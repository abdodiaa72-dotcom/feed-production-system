import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { workers } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  const data = await db.select().from(workers).orderBy(desc(workers.id));
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const totalCost = (
      parseFloat(body.workerCount) * parseFloat(body.workerDailyPay || "0")
    ).toFixed(2);

    const [item] = await db
      .insert(workers)
      .values({
        date: body.date,
        workerCount: parseInt(body.workerCount),
        taskType: body.taskType,
        tonsMade: body.tonsMade || "0",
        pricePerTon: body.pricePerTon || "0",
        workerDailyPay: body.workerDailyPay || "0",
        totalCost,
        notes: body.notes || null,
      })
      .returning();
    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
