import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { feedTypes } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const data = await db.select().from(feedTypes).orderBy(desc(feedTypes.id));
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const [item] = await db
      .insert(feedTypes)
      .values({
        name: body.name,
        category: body.category || null,
        pricePerTon: body.pricePerTon || "0",
        stockQuantity: body.stockQuantity || "0",
      })
      .returning();
    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const [item] = await db
      .update(feedTypes)
      .set({
        name: body.name,
        category: body.category,
        pricePerTon: body.pricePerTon,
        stockQuantity: body.stockQuantity,
      })
      .where(eq(feedTypes.id, body.id))
      .returning();
    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
