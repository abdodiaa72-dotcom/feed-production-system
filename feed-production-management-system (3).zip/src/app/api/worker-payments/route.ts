import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { workerPayments, workersList, treasury } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export async function GET() {
  const data = await db
    .select({
      id: workerPayments.id,
      workerId: workerPayments.workerId,
      workerName: workersList.name,
      type: workerPayments.type,
      amount: workerPayments.amount,
      date: workerPayments.date,
      notes: workerPayments.notes,
    })
    .from(workerPayments)
    .leftJoin(workersList, eq(workerPayments.workerId, workersList.id))
    .orderBy(desc(workerPayments.id));
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const [item] = await db
      .insert(workerPayments)
      .values({
        workerId: parseInt(body.workerId),
        type: body.type,
        amount: body.amount,
        date: body.date,
        notes: body.notes || null,
      })
      .returning();

    // Update worker balance
    if (body.type === "payment") {
      // صرف للعامل - ينقص من رصيده المستحق
      await db
        .update(workersList)
        .set({
          balance: sql`${workersList.balance}::numeric - ${body.amount}::numeric`,
        })
        .where(eq(workersList.id, parseInt(body.workerId)));

      // Deduct from treasury
      await db.insert(treasury).values({
        date: body.date,
        description: `صرف مستحقات عامل - ${body.notes || ""}`,
        amountIn: "0",
        amountOut: body.amount,
        balance: "0",
        referenceType: "worker_payment",
        referenceId: item.id,
      });
    } else if (body.type === "deduction") {
      // خصم من العامل - ينقص من مستحقاته
      await db
        .update(workersList)
        .set({
          balance: sql`${workersList.balance}::numeric - ${body.amount}::numeric`,
        })
        .where(eq(workersList.id, parseInt(body.workerId)));
    } else if (body.type === "advance") {
      // سلفة للعامل - ندفع له مقدماً (ينقص من مستحقاته)
      await db
        .update(workersList)
        .set({
          balance: sql`${workersList.balance}::numeric - ${body.amount}::numeric`,
        })
        .where(eq(workersList.id, parseInt(body.workerId)));

      // Deduct from treasury
      await db.insert(treasury).values({
        date: body.date,
        description: `سلفة عامل - ${body.notes || ""}`,
        amountIn: "0",
        amountOut: body.amount,
        balance: "0",
        referenceType: "worker_advance",
        referenceId: item.id,
      });
    }

    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
