import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { dailyWork, workerAttendance, workersList } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export async function GET() {
  const data = await db
    .select()
    .from(dailyWork)
    .orderBy(desc(dailyWork.id));

  // Get attendance for each daily work
  const result = await Promise.all(
    data.map(async (dw) => {
      const attendance = await db
        .select({
          id: workerAttendance.id,
          workerId: workerAttendance.workerId,
          workerName: workersList.name,
          amountEarned: workerAttendance.amountEarned,
        })
        .from(workerAttendance)
        .leftJoin(workersList, eq(workerAttendance.workerId, workersList.id))
        .where(eq(workerAttendance.dailyWorkId, dw.id));

      return { ...dw, workers: attendance };
    })
  );

  return NextResponse.json(result);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const workerCount = body.workers?.length || 0;
    const totalAmount = body.totalAmount || "0";

    // Calculate amount per worker
    const amountPerWorker = workerCount > 0
      ? (parseFloat(totalAmount) / workerCount).toFixed(2)
      : "0";

    // Create daily work record
    const [dw] = await db
      .insert(dailyWork)
      .values({
        date: body.date,
        taskType: body.taskType,
        tonsMade: body.tonsMade || "0",
        pricePerTon: body.pricePerTon || "0",
        totalAmount,
        notes: body.notes || null,
      })
      .returning();

    // Add worker attendance and update their balance
    if (body.workers && Array.isArray(body.workers)) {
      for (const workerId of body.workers) {
        await db.insert(workerAttendance).values({
          dailyWorkId: dw.id,
          workerId: parseInt(workerId),
          amountEarned: amountPerWorker,
        });

        // Update worker balance (add to their earnings)
        await db
          .update(workersList)
          .set({
            balance: sql`${workersList.balance}::numeric + ${amountPerWorker}::numeric`,
          })
          .where(eq(workersList.id, parseInt(workerId)));
      }
    }

    return NextResponse.json(dw);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
