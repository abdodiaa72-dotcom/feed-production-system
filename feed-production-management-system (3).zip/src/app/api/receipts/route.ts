import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { receipts, customers, treasury } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export async function GET() {
  const data = await db
    .select({
      id: receipts.id,
      customerId: receipts.customerId,
      type: receipts.type,
      amount: receipts.amount,
      date: receipts.date,
      notes: receipts.notes,
      customerName: customers.name,
    })
    .from(receipts)
    .leftJoin(customers, eq(receipts.customerId, customers.id))
    .orderBy(desc(receipts.id));
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const [item] = await db
      .insert(receipts)
      .values({
        customerId: body.customerId,
        type: body.type,
        amount: body.amount,
        date: body.date,
        notes: body.notes || null,
      })
      .returning();

    // Update customer balance
    if (body.type === "receipt") {
      // سند قبض - العميل دفع (ينقص من رصيده)
      await db
        .update(customers)
        .set({
          balance: sql`${customers.balance}::numeric - ${body.amount}::numeric`,
        })
        .where(eq(customers.id, body.customerId));

      // Add to treasury
      await db.insert(treasury).values({
        date: body.date,
        description: `سند قبض - ${body.notes || ""}`,
        amountIn: body.amount,
        amountOut: "0",
        balance: "0",
        referenceType: "receipt",
        referenceId: item.id,
      });
    } else {
      // سند صرف - ندفع للعميل (يزيد رصيده)
      await db
        .update(customers)
        .set({
          balance: sql`${customers.balance}::numeric + ${body.amount}::numeric`,
        })
        .where(eq(customers.id, body.customerId));

      await db.insert(treasury).values({
        date: body.date,
        description: `سند صرف - ${body.notes || ""}`,
        amountIn: "0",
        amountOut: body.amount,
        balance: "0",
        referenceType: "payment",
        referenceId: item.id,
      });
    }

    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
