import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { sql } from "drizzle-orm";

export async function POST() {
  try {
    // Check if admin already exists
    const existing = await db
      .select()
      .from(users)
      .limit(1);

    if (existing.length > 0) {
      return NextResponse.json({ message: "Users already exist" });
    }

    const adminPass = await hashPassword("admin123");
    const accountantPass = await hashPassword("accountant123");

    await db.insert(users).values([
      { username: "admin", password: adminPass, role: "admin" },
      { username: "accountant", password: accountantPass, role: "accountant" },
    ]);

    return NextResponse.json({ message: "Seeded successfully" });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Seed failed" }, { status: 500 });
  }
}

export async function GET() {
  // Same as POST for convenience
  try {
    const existing = await db.select().from(users).limit(1);
    if (existing.length > 0) {
      return NextResponse.json({ message: "Users already exist" });
    }

    const adminPass = await hashPassword("admin123");
    const accountantPass = await hashPassword("accountant123");

    await db.insert(users).values([
      { username: "admin", password: adminPass, role: "admin" },
      { username: "accountant", password: accountantPass, role: "accountant" },
    ]);

    return NextResponse.json({ message: "Seeded successfully" });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Seed failed" }, { status: 500 });
  }
}
