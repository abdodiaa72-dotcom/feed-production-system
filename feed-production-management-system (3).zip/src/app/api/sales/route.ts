import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { sales, feedTypes, customers, treasury } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export async function GET() {
  const data = await db
    .select({
      id: sales.id,
      customerId: sales.customerId,
      feedTypeId: sales.feedTypeId,
      quantity: sales.quantity,
      pricePerTon: sales.pricePerTon,
      totalPrice: sales.totalPrice,
      paymentType: sales.paymentType,
      date: sales.date,
      notes: sales.notes,
      customerName: customers.name,
      feedTypeName: feedTypes.name,
    })
    .from(sales)
    .leftJoin(customers, eq(sales.customerId, customers.id))
    .leftJoin(feedTypes, eq(sales.feedTypeId, feedTypes.id))
    .orderBy(desc(sales.id));
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const totalPrice = (
      parseFloat(body.quantity) * parseFloat(body.pricePerTon)
    ).toFixed(2);

    const [item] = await db
      .insert(sales)
      .values({
        customerId: body.customerId,
        feedTypeId: body.feedTypeId,
        quantity: body.quantity,
        pricePerTon: body.pricePerTon,
        totalPrice,
        paymentType: body.paymentType,
        date: body.date,
        notes: body.notes || null,
      })
      .returning();

    // Deduct feed stock
    await db
      .update(feedTypes)
      .set({
        stockQuantity: sql`${feedTypes.stockQuantity}::numeric - ${body.quantity}::numeric`,
      })
      .where(eq(feedTypes.id, body.feedTypeId));

    // If credit, update customer balance
    if (body.paymentType === "credit") {
      await db
        .update(customers)
        .set({
          balance: sql`${customers.balance}::numeric + ${totalPrice}::numeric`,
        })
        .where(eq(customers.id, body.customerId));
    }

    // If cash, add to treasury
    if (body.paymentType === "cash") {
      await db.insert(treasury).values({
        date: body.date,
        description: `مبيعات نقدي - ${body.notes || ""}`,
        amountIn: totalPrice,
        amountOut: "0",
        balance: "0",
        referenceType: "sale",
        referenceId: item.id,
      });
    }

    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
