import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { workersList } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const data = await db
    .select()
    .from(workersList)
    .orderBy(desc(workersList.id));
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const [item] = await db
      .insert(workersList)
      .values({
        name: body.name,
        phone: body.phone || null,
        nationalId: body.nationalId || null,
        address: body.address || null,
        dailyRate: body.dailyRate || "0",
        balance: "0",
        isActive: true,
      })
      .returning();
    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const [item] = await db
      .update(workersList)
      .set({
        name: body.name,
        phone: body.phone,
        nationalId: body.nationalId,
        address: body.address,
        dailyRate: body.dailyRate,
        isActive: body.isActive,
      })
      .where(eq(workersList.id, body.id))
      .returning();
    return NextResponse.json(item);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
