import {
  pgTable,
  serial,
  varchar,
  text,
  integer,
  decimal,
  timestamp,
  date,
  boolean,
} from "drizzle-orm/pg-core";

// ============ USERS ============
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  role: varchar("role", { length: 50 }).notNull().default("accountant"), // admin | accountant
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ SUPPLIERS (موردين) ============
export const suppliers = pgTable("suppliers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  address: text("address"),
  balance: decimal("balance", { precision: 12, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ CUSTOMERS (عملاء) ============
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  address: text("address"),
  balance: decimal("balance", { precision: 12, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ RAW MATERIALS (خامات) ============
export const materials = pgTable("materials", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  unit: varchar("unit", { length: 50 }).notNull().default("كجم"),
  quantity: decimal("quantity", { precision: 12, scale: 2 }).default("0"),
  pricePerUnit: decimal("price_per_unit", { precision: 12, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ FEED TYPES (أصناف العلف) ============
export const feedTypes = pgTable("feed_types", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }),
  pricePerTon: decimal("price_per_ton", { precision: 12, scale: 2 }).default("0"),
  stockQuantity: decimal("stock_quantity", { precision: 12, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ PURCHASES (مشتريات) ============
export const purchases = pgTable("purchases", {
  id: serial("id").primaryKey(),
  supplierId: integer("supplier_id").references(() => suppliers.id),
  materialId: integer("material_id").references(() => materials.id),
  quantity: decimal("quantity", { precision: 12, scale: 2 }).notNull(),
  pricePerUnit: decimal("price_per_unit", { precision: 12, scale: 2 }).notNull(),
  totalPrice: decimal("total_price", { precision: 12, scale: 2 }).notNull(),
  paymentType: varchar("payment_type", { length: 20 }).notNull(), // cash | credit (أجل)
  date: date("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ SALES (مبيعات) ============
export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id),
  feedTypeId: integer("feed_type_id").references(() => feedTypes.id),
  quantity: decimal("quantity", { precision: 12, scale: 2 }).notNull(),
  pricePerTon: decimal("price_per_ton", { precision: 12, scale: 2 }).notNull(),
  totalPrice: decimal("total_price", { precision: 12, scale: 2 }).notNull(),
  paymentType: varchar("payment_type", { length: 20 }).notNull(), // cash | credit
  date: date("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ MANUFACTURING (تصنيع) ============
export const manufacturing = pgTable("manufacturing", {
  id: serial("id").primaryKey(),
  feedTypeId: integer("feed_type_id").references(() => feedTypes.id),
  quantityTons: decimal("quantity_tons", { precision: 12, scale: 2 }).notNull(),
  date: date("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ MANUFACTURING MATERIALS (خامات التصنيع) ============
export const manufacturingMaterials = pgTable("manufacturing_materials", {
  id: serial("id").primaryKey(),
  manufacturingId: integer("manufacturing_id").references(() => manufacturing.id),
  materialId: integer("material_id").references(() => materials.id),
  quantityUsed: decimal("quantity_used", { precision: 12, scale: 2 }).notNull(),
});

// ============ WORKER LIST (قائمة العمال) ============
export const workersList = pgTable("workers_list", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  nationalId: varchar("national_id", { length: 20 }),
  address: text("address"),
  dailyRate: decimal("daily_rate", { precision: 12, scale: 2 }).default("0"),
  balance: decimal("balance", { precision: 12, scale: 2 }).default("0"), // المستحقات
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ DAILY WORK RECORDS (سجل العمل اليومي) ============
export const dailyWork = pgTable("daily_work", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  taskType: varchar("task_type", { length: 100 }).notNull(), // تعتيق | تحميل | تصنيع
  tonsMade: decimal("tons_made", { precision: 12, scale: 2 }).default("0"),
  pricePerTon: decimal("price_per_ton", { precision: 12, scale: 2 }).default("0"),
  totalAmount: decimal("total_amount", { precision: 12, scale: 2 }).default("0"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ WORKER ATTENDANCE (حضور العمال) ============
export const workerAttendance = pgTable("worker_attendance", {
  id: serial("id").primaryKey(),
  dailyWorkId: integer("daily_work_id").references(() => dailyWork.id),
  workerId: integer("worker_id").references(() => workersList.id),
  amountEarned: decimal("amount_earned", { precision: 12, scale: 2 }).default("0"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ WORKER PAYMENTS (سندات العمال) ============
export const workerPayments = pgTable("worker_payments", {
  id: serial("id").primaryKey(),
  workerId: integer("worker_id").references(() => workersList.id),
  type: varchar("type", { length: 20 }).notNull(), // payment (صرف) | deduction (خصم)
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  date: date("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ LEGACY WORKERS (للتوافق) ============
export const workers = pgTable("workers", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  workerCount: integer("worker_count").notNull(),
  taskType: varchar("task_type", { length: 100 }).notNull(),
  tonsMade: decimal("tons_made", { precision: 12, scale: 2 }).default("0"),
  pricePerTon: decimal("price_per_ton", { precision: 12, scale: 2 }).default("0"),
  workerDailyPay: decimal("worker_daily_pay", { precision: 12, scale: 2 }).default("0"),
  totalCost: decimal("total_cost", { precision: 12, scale: 2 }).default("0"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ EXPENSES (مصروفات) ============
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  description: varchar("description", { length: 500 }).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  category: varchar("category", { length: 100 }),
  date: date("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ TREASURY (الخزنة) ============
export const treasury = pgTable("treasury", {
  id: serial("id").primaryKey(),
  date: date("date").notNull(),
  description: varchar("description", { length: 500 }).notNull(),
  amountIn: decimal("amount_in", { precision: 12, scale: 2 }).default("0"),
  amountOut: decimal("amount_out", { precision: 12, scale: 2 }).default("0"),
  balance: decimal("balance", { precision: 12, scale: 2 }).default("0"),
  referenceType: varchar("reference_type", { length: 50 }),
  referenceId: integer("reference_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// ============ RECEIPTS (سندات قبض وصرف) ============
export const receipts = pgTable("receipts", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id),
  type: varchar("type", { length: 20 }).notNull(), // receipt (قبض) | payment (صرف)
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  date: date("date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});
